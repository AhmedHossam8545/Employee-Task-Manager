
# Employee & Task Manager API

## Install
```bash
npm install
```

## Run
```bash
npm run dev
```

## Endpoints
See the challenge description for all available endpoints.
